for index in 1...180 {
    print("\(index)s")
    if index == 60 {
    print("1min")
    } else if index == 120 {
    print("2min")
    } else if index == 180 {
    print("3min")
    }
}
