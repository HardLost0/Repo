enum sandWich {
    case item(String)
}
var sandWichItems = sandWich.item("Bread,Ham,Cheese")

switch sandWichItems {
    case .item(let sandWichItems):
        print("The items in your sandwich is: \(sandWichItems)")
}
