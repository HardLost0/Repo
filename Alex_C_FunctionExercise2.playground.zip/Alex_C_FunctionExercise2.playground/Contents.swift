// Multiplying Function
let total = {
    (num1: Int, num2: Int) -> Int in
    return num1 * num2
}
// Change the Variables aka 10 or 5 to find out other answers
let sum = total(10,5)
print(sum)
