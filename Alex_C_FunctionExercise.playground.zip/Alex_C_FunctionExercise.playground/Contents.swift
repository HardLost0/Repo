// Function to add two numbers
func addingNumbers(num1: Int, num2: Int) ->Int  {
    return num1 + num2
}
// Print Numbers by adding num1 + num2
print(addingNumbers(num1: 2, num2: 23))
