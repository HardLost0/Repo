// Collection exercise

//Create an array of items you collect (ie Action Figures, Coins, etc)


var money:[String] = []
// Adding All The Money
money += ["Penny"]
money += ["Nickel"]
money += ["Dime"]
money += ["Quarter"]
money += ["Dollar"]
money += ["Five Dollar"]
money += ["Ten Dollar"]
money += ["One Hundred Dollar"]
print(money)
//Before sorted ^^
money.sort()
print(money)
// After Sorted ^^
