let sum = 2
let number = Int.random(in:0..<10)
let add = number + sum
let subtract = number - sum
let multiply = number * sum
let divide = number % sum
print(add)
print(subtract)
print(multiply)
print(divide)
