import Foundation

public func driveAcrossTown() {

}

public func buyACoffeeMaker() {

}

public func findCoffeeGrinder() {

}

public func findCoffeeBeans() {

}

public func driveHome() {

}

public func makeFriendDrinkCoffee() {
    
}

public func setUpCoffeeGrinder() {

}

public func grindBeans() {

}
